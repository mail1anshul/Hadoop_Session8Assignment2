package stringConcatWS;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;
import org.codehaus.plexus.util.StringUtils;

public class stringConcatWS extends UDF
{
	Text colValue = new Text();
	public Text evaluate(Text arraydata, String separator)
	{
		colValue.set(StringUtils.replace(arraydata.toString(),",",separator));	
		return colValue;
	}
	
}
